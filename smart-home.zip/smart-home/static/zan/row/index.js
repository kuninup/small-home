'use strict'

Component({
  externalClasses: ['row-class'],

  relations: {
    '../col/index': {
      type: 'child'
    }
  }
})
