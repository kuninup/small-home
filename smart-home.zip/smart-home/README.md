# 概述
  本项目是参照米家App布局和配色, 基于[mpvue](http://mpvue.com/), [iview](https://weapp.iviewui.com/), [zanui](https://www.youzanyun.com/zanui)编写的一个小程序代码,项目只编写了几个有代表性的页面,用于交流学习.

# 效果
  ![](https://github.com/tustman/smart-home/blob/master/screenshot/000.gif)


# smart-home

> smart-home

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
