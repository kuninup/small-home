# encoding:utf-8
import base64
import urllib
import requests
import json
import os
import cv2
import sys
from flask import Flask, jsonify, abort, request
app = Flask(__name__)

@app.route('/')
def index():
    '''
    Welcome interface
    '''
    return "Hello, World!"

@app.route('/take_and_predict_photo', methods=['GET'])
def take_and_predict_photo():
    if not request.method == 'GET':
        abort(500)

    print("============")
    take_photo()

    print("------------")

    result = get_cloth_name("img.png")

    return jsonify({'result': result})

def take_photo():
    print("fasfasdfasd")
    cap = cv2.VideoCapture(2)
    cap.set(3,640)
    cap.set(4,480)
    cap.set(1, 10.0)

    while True:
        ret,frame = cap.read(0)
        if ret == True:
            frame = cv2.flip(frame, 1)
            # a = out.write(frame)
            cv2.imshow("frame", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                cv2.imwrite("img.png",frame)
                break
        else:
            break
    cap.release()
    # out.release()
    cv2.destroyAllWindows()

def get_cloth_name(imagePath):
    '''
    通用物体和场景识别
    '''
    request_url = "https://aip.baidubce.com/rest/2.0/image-classify/v2/advanced_general"

    # 二进制方式打开图片文件
    f = open(imagePath, 'rb')
    img = base64.b64encode(f.read())


    params = {"image":img}
    params = urllib.parse.urlencode(params).encode(encoding='UTF-8')

    access_token = '24.84a4f3c1a9fe96eea7937bb66b275d17.2592000.1561354262.282335-11182981'
    request_url = request_url + "?access_token=" + access_token
    request = urllib.request.Request(url=request_url, data=params)
    request.add_header('Content-Type', 'application/x-www-form-urlencoded')
    response = urllib.request.urlopen(request)
    content = response.read()
    if content:
        content = content.decode("utf8")
    result = json.loads(content)
    result = result["result"]
    for item in result:
        if "袜" in item["keyword"]:
            return "1"
        if "鞋" in item["keyword"]:
            return "2"
    return "0"
# print(get_cloth_name("2.jpg"))

if __name__ == '__main__':
    app.run(host = '127.0.0.1', port = 8000 , debug=True)
